export class Ingrident {
  // public name:string;
  // public amount:number;
  constructor(public name:string , public amount:number){
    // this.name = name,
    // this.amount =amount
  }
}
